package com.example.demo.error;
public class TeacherNotFoundException extends Exception {
	
	 public TeacherNotFoundException(String message) {
		 
		 super(message);
	}	 
}