package com.example.demo.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Teacher;
import com.example.demo.error.TeacherNotFoundException;
import com.example.demo.repository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService {
	
	 @Autowired
	 private TeacherRepository teacherRepository;

	 
	@Override
	public Teacher addTeacher(Teacher teacher) {

		return teacherRepository.save(teacher) ;
	}


	@Override
	public List<Teacher> getAllTeacher() {
		
		return teacherRepository.findAll();
	}


	@Override
	public void deleteById(Integer tid) throws TeacherNotFoundException {
		
		Optional<Teacher> teacher = teacherRepository.findById(tid);
		
		   if(!teacher.isPresent()) {
			   
			   throw new TeacherNotFoundException("Teacher Id not Found");
		   }
		   
		   else {
			   
			    teacherRepository.deleteById(tid);
		   }
	    }


	@Override
	public Teacher updateTeacher(Integer tid, Teacher teacher) throws TeacherNotFoundException {
		
		Optional<Teacher> teacher1 = teacherRepository.findById(tid);
		
		  if(!teacher1.isPresent()) {
			  
			  throw new TeacherNotFoundException("Tecaher Id not Found");
		  }
		  
		  else {
			  
			  Teacher t = teacherRepository.findById(tid).get();
			  
			    if(teacher.getTeacherName()!=null)
			    	
			    	t.setTeacherName(teacher.getTeacherName());
		  
		        if(teacher.getTeacherSalary()!=0)
		        	
		        	t.setTeacherSalary(teacher.getTeacherSalary());
		
		           return teacherRepository.save(teacher) ;
	         }
	     }


	@Override
	public Teacher findById(Integer tid) throws TeacherNotFoundException {
		
		Optional<Teacher> teacher = teacherRepository.findById(tid);
		
		   if(!teacher.isPresent()) {
			   
			   throw new TeacherNotFoundException("Teacher Id not Found");
		   }
		   
		   else {
			   
			   return teacherRepository.findById(tid).get();
		   }
	   }


	@Override
	public Teacher findByTeacherName(String teacherName) throws TeacherNotFoundException {
		
		Teacher teacher = teacherRepository.findByTeacherName(teacherName);
		
		   if(teacher==null) {
			   
			   throw new TeacherNotFoundException("Teacher Name not Found");
		   }
		   
		   else {
			   
			   return teacherRepository.findByTeacherName(teacherName);
		   }
	    }
	
}