package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;

public interface DepartmentService {

	Department deparmentSave(Department department);

	List<Department> getAllDepartments();

	Department findDepartmentById(Long deptid);

	void deleteDeparmentId(Long deptid) throws DepartmentNotFoundException;

	Department updateDepartment(Long departmentId, Department department);

	Department fetchDepartmentByName(String deptname);

	Department fetchDepartmentByAdress(String deptadress);

	Department fetchDepartmentById(Long depertmentID) throws DepartmentNotFoundException;

	void deleteDeparment(Long departmentId) throws DepartmentNotFoundException;



	

	

}
