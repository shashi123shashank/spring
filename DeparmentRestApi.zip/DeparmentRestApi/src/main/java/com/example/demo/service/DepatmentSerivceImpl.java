package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.repository.DepartmentRepository;
@Service
public  class DepatmentSerivceImpl implements DepartmentService{
	@Autowired
private DepartmentRepository deparmentRepository;

	@Override
	public Department deparmentSave(Department department) {
		
		return deparmentRepository.save(department);
	}

	@Override
	public List<Department> getAllDepartments() {
	
		return deparmentRepository.findAll();
	}

	@Override
	public Department fetchDepartmentById(Long depertmentID)throws DepartmentNotFoundException {
	//return deparmentRepository.findById(deptid).get();
	Optional<Department>department=deparmentRepository.findById(depertmentID);
	if(!department.isPresent())
		throw new DepartmentNotFoundException("department ID not found");
		return department.get();
	
	}

	@Override
	public void deleteDeparment(Long departmentId) throws DepartmentNotFoundException {
	Optional<Department>	department= deparmentRepository.findById(departmentId);
	if(!department.isPresent())
		throw new DepartmentNotFoundException("Department Id Not found");
	deparmentRepository.deleteById(departmentId);
		
		
	}

	@Override
	public Department updateDepartment(Long departmentId, Department department) {
		Department deptDB =deparmentRepository.findById(departmentId).get();
		if(department.getDepartmentAdress()!=null)
			deptDB.setDepartmentAdress(department.getDepartmentAdress());
		if(department.getDepartmentName()!=null)
			deptDB.setDepartmentName(department.getDepartmentName());
		return deparmentRepository.save(deptDB);
	}

	@Override
	public Department fetchDepartmentByName(String deptname) {
		
		return deparmentRepository.findByDepartmentName(deptname);
	}

	@Override
	public Department fetchDepartmentByAdress(String deptadress) {
		
		return deparmentRepository.findByDepartmentAdress(deptadress);
	}

	@Override
	public Department findDepartmentById(Long deptid) {
		// TODO Auto-generated method stub
		return null;

	
	}

	@Override
	public void deleteDeparmentId(Long deptid) throws DepartmentNotFoundException {
		// TODO Auto-generated method stub
		
	}
	
		
	}



