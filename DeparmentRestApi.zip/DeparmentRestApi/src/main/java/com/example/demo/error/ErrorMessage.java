package com.example.demo.error;

import org.springframework.http.HttpStatus;

public class ErrorMessage {
	private HttpStatus staus;
	private String message;
	public ErrorMessage() {
		super();
	}
	public ErrorMessage(HttpStatus status, String message) {
		
	}
	public HttpStatus getStaus() {
		return staus;
	}
	public void setStaus(HttpStatus staus) {
		this.staus = staus;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
