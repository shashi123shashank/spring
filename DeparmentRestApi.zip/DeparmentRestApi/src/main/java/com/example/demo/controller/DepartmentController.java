package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController {
	//Inject an
	@Autowired
	private DepartmentService deparmentService;
	
	@PostMapping("/adddepartment")
public Department departmentSave(@RequestBody Department department) {
		
	
	return deparmentService.deparmentSave(department);
}
	@GetMapping("/getalldepartments")
		public List<Department> getAllDepartments(){
			return deparmentService.getAllDepartments();
		}
	@GetMapping("/getdepartmentbyid/{deptid}")
	public Department fetchDepartmentById(@PathVariable("deptid") Long departmentId)throws DepartmentNotFoundException {
		return deparmentService.fetchDepartmentById(departmentId);
	}
	@DeleteMapping("/deletebyid/{deptid}")
public String deleteDepartmentId(@PathVariable("deptid") Long departmentId) throws DepartmentNotFoundException {
	deparmentService.deleteDeparmentId(departmentId);
	return "Departmentd deleted successfully";
}
	@PutMapping("updatedepartment/{deptid}")
public Department updateDepartment(@PathVariable("deptid") Long departmentId,@RequestBody Department department) {
	return deparmentService.updateDepartment(departmentId,department);
}
	//findByName
		@GetMapping("/getdepartmentByName/{name}")
			public Department fetchDepartmentByName(@PathVariable("name") String deptname) {
			return deparmentService.fetchDepartmentByName(deptname);
		}
		@GetMapping("/getdepartmentByAdress/{adress}")
		public Department fetchDepartmentByAdress(@PathVariable("adress") String deptadress) {
		return deparmentService.fetchDepartmentByAdress(deptadress);
				
		}	

}